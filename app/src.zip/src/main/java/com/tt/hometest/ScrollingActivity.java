package com.tt.hometest;

import android.animation.LayoutTransition;
import android.app.Activity;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Bundle;

import com.bumptech.glide.Glide;
import com.google.android.material.appbar.AppBarLayout;
import com.google.android.material.appbar.CollapsingToolbarLayout;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;
import com.google.gson.Gson;
import com.tt.hometest.model.banner.BannerItems;
import com.tt.hometest.model.quicklink.QuickLinkItems;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.content.ContextCompat;
import androidx.core.widget.NestedScrollView;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewpager.widget.ViewPager;
import androidx.viewpager2.adapter.FragmentStateAdapter;
import androidx.viewpager2.widget.ViewPager2;

import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.Toast;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

public class ScrollingActivity extends AppCompatActivity {

    Toast toast;
    ViewPager2 viewPager;
    RecyclerView quickLinkView;
    RecyclerView flashDealView;
    FrameLayout bannerParent, quickLinkParent, flashDealParent;
    ProgressBar bannerProgressBar, quickLinkProgressBar, flashDealProgressBar;
    //ArrayList<BannerlItem> bannerItems;
    BannerItems bannerItems;
    //ArrayList<QuickLinkItem> quickLinkItems;
    QuickLinkItems quickLinkItems;
    ArrayList<FlashDealItem> flashDealItems;

    OkHttpClient client = new OkHttpClient();
    Gson gson = new Gson();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_scrolling);
        transparentStatusBar();
        final Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayShowTitleEnabled(false);
        final ImageView imageView = new ImageView(this);
        imageView.setImageDrawable(ContextCompat.getDrawable(this, R.drawable.ic_launcher_background));
        Toolbar.LayoutParams layoutParams = new Toolbar.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.MATCH_PARENT, Gravity.CENTER);
        int logoMargin = getResources().getDimensionPixelSize(R.dimen.logo_margin);
        layoutParams.setMargins(0, logoMargin, 0, logoMargin);
        toolbar.addView(imageView, layoutParams);


        final AppBarLayout appBar = findViewById(R.id.app_bar);
        final SearchBar searchBar = findViewById(R.id.searchBar);
        //final ImageView imageView = appBar.findViewById(R.id.imageView);
        CollapsingToolbarLayout collapsingToolbarLayout  = appBar.findViewById(R.id.toolbar_layout);
        collapsingToolbarLayout.setTitleEnabled(false);
        final int searchBarMarginRight = getResources().getDimensionPixelSize(R.dimen.search_bar_margin_right);
        appBar.addOnOffsetChangedListener(new AppBarLayout.OnOffsetChangedListener() {
            @Override
            public void onOffsetChanged(AppBarLayout appBarLayout, int verticalOffset) {
                System.out.println("======= offset " + verticalOffset + " " + appBarLayout.getTotalScrollRange());
                float totalScrollRange = appBar.getTotalScrollRange();
                float scrollProgress =  Math.abs(verticalOffset/totalScrollRange);
                int r = (int) (scrollProgress * searchBarMarginRight);
                imageView.setAlpha(1 - scrollProgress);
                searchBar.setEditTextCollapsed(scrollProgress > 0);
                //System.out.println("======= offset " + r + " " + searchBarPaddingRight + " " + verticalOffset/totalScrollRange) ;
               /* FrameLayout.LayoutParams lp = (FrameLayout.LayoutParams) searchBar.getLayoutParams();
                if (r != lp.getMarginEnd()) {
                    lp.setMarginEnd(r);
                    searchBar.setLayoutParams(lp);
                }*/
                searchBar.setMarginRight(r);

            }
        });
        bannerParent = findViewById(R.id.bannerParent);
        quickLinkParent = findViewById(R.id.quickLinkParent);
        flashDealParent = findViewById(R.id.flashDealParent);
        viewPager = bannerParent.findViewById(R.id.banner);
        quickLinkView = quickLinkParent.findViewById(R.id.quickLink);
        flashDealView = flashDealParent.findViewById(R.id.flashDeal);
        bannerProgressBar = bannerParent.findViewById(R.id.bannerProgressBar);
        quickLinkProgressBar = quickLinkParent.findViewById(R.id.quickLinkProgressBar);
        flashDealProgressBar = flashDealParent.findViewById(R.id.flashDealProgressBar);

        /*NestedScrollView scrollView = findViewById(R.id.scrollView2);
        LayoutTransition layoutTransition = scrollView.getLayoutTransition();
        layoutTransition.enableTransitionType(LayoutTransition.CHANGING);*/

        quickLinkParent.setVisibility(View.GONE);
        flashDealParent.setVisibility(View.GONE);
        viewPager.setVisibility(View.INVISIBLE);
        quickLinkView.setVisibility(View.INVISIBLE);
        flashDealView.setVisibility(View.INVISIBLE);

        /*String[] bannerUrl = {
                "https://salt.tikicdn.com/cache/w750/ts/banner/80/98/73/8e3d0f65e93bd9266e66289b22263941.jpg",
                "https://salt.tikicdn.com/cache/w750/ts/banner/70/9b/1b/a5478fae578512a17eb4b1081b3df769.jpg",
                "https://salt.tikicdn.com/cache/w750/ts/banner/64/44/94/86964888f6829b063b1dd77df23ff2e1.jpg",
                "https://salt.tikicdn.com/cache/w750/ts/banner/90/e9/67/8c824d2b51aec8ad911eac38e7d3c670.jpg",
                "https://salt.tikicdn.com/cache/w750/ts/banner/b1/80/c2/e99e31697de64ce8a9ed8b2ed0d97cc2.jpg",
                "https://salt.tikicdn.com/cache/w750/ts/banner/28/72/b9/5d469af733d94aad48d5591eb0c229d1.jpg",
                "https://salt.tikicdn.com/cache/w750/ts/banner/19/65/0b/8fe3aac04b3be04702ac6e606a653a14.jpg",
                "https://salt.tikicdn.com/cache/w750/ts/banner/22/6b/44/2b21da0431541fc69558b7d12e411577.jpg",
                "https://salt.tikicdn.com/cache/w750/ts/banner/ab/25/82/a47dba5fbcfba0646484aaddde338706.jpg",
                "https://salt.tikicdn.com/cache/w750/ts/banner/90/b1/64/22a6b13f01dbce9a78a86251c83ac064.jpg",
                "https://salt.tikicdn.com/cache/w750/ts/banner/56/ad/c1/c32ab75ed4693779aa80224466f0fb0a.jpg",
                "https://salt.tikicdn.com/cache/w750/ts/banner/9f/b4/e8/fc021f4f9975d7be5f41bddfa15a28af.jpg"
        };

        bannerItems = new ArrayList<>(bannerUrl.length);
        for (int i=0; i< bannerUrl.length; ++i) {
            bannerItems.add(new BannerlItem(bannerUrl[i]));
        }*/

        /*String[] quickLinkUrl = {
                "https://salt.tikicdn.com/ts/upload/73/50/e1/83afc85db37c472de60ebef6eceb41a7.png",
                "https://salt.tikicdn.com/ts/upload/79/76/e8/f09488f10ea645f4ccbac28ae20e8f9e.png",
                "https://salt.tikicdn.com/ts/upload/db/1e/2d/07dc4d7136b450a3d2e1e689582213b2.png",
                "https://salt.tikicdn.com/ts/upload/52/50/73/0788d5207ec8b82e05859dfe953a4327.png",
                "https://salt.tikicdn.com/ts/upload/e7/32/e2/c6a50df6d04cf212dcbda300e3cb8654.png",
                "https://salt.tikicdn.com/ts/upload/58/26/1b/b98f5fc231b4505700bf7da5481fedad.png",
                "https://salt.tikicdn.com/ts/upload/81/f2/80/c130002f1ffd5c1131812366d502e36a.png",
                "https://salt.tikicdn.com/ts/upload/ec/a9/8e/3040afd931ce300038790ce6c9ad4f76.png",
                "https://salt.tikicdn.com/ts/upload/ce/ee/fe/a8a350727b38a1e20ce1610c5162fcb7.png",
                "https://salt.tikicdn.com/ts/upload/0b/68/92/c5366849dc64b513569947c111117d8f.png",
                "https://salt.tikicdn.com/ts/upload/a0/0d/90/bab67b6da67117f40538fc54fb2dcb5e.png",
                "https://salt.tikicdn.com/ts/upload/4a/b2/c5/b388ee0e511889c83fab1217608fe82f.png",
                "https://salt.tikicdn.com/ts/upload/f2/5f/22/dae57676693b7665b734e36c5fb69809.png"};

        quickLinkItems = new ArrayList<>(quickLinkUrl.length);

        for (int i=0; i<quickLinkUrl.length; ++i) {
            quickLinkItems.add(new QuickLinkItem(quickLinkUrl[i]));
        }*/

        String[] flashDealUrl = {
                "https://salt.tikicdn.com/cache/280x280/ts/product/df/7d/da/cc713d2bcecd12ba82d5596ddbcac2d7.jpg",
                "https://salt.tikicdn.com/cache/280x280/ts/product/57/44/86/19de0644beef19b9b885d0942f7d6f25.jpg",
                "https://salt.tikicdn.com/cache/280x280/ts/product/d7/7c/78/3c09e7a477fd3c16340216cf849bb025.jpg",
                "https://salt.tikicdn.com/cache/280x280/ts/product/fc/79/ba/4d2edb20182dfe58e20d1ce24db3d349.jpg",
                "https://salt.tikicdn.com/cache/280x280/ts/product/f2/bf/8b/e1f1f47e23807edbff04d0c0bf2edb62.jpg",
                "https://salt.tikicdn.com/cache/280x280/ts/product/91/66/17/b6c2b0965967d8400e8be41db37e4095.jpg",
                "https://salt.tikicdn.com/cache/280x280/ts/product/a4/6f/85/fac7eac951cba4b79167be98bbbf46fc.jpg",
                "https://salt.tikicdn.com/cache/280x280/ts/product/06/d0/df/06e3689a170c6361318c955260a28b50.jpg",
                "https://salt.tikicdn.com/cache/280x280/ts/product/ed/13/95/899a55e9471413026dc110c908389c5e.jpg",
                "https://salt.tikicdn.com/cache/280x280/media/catalog/product/i/m/img850.u547.d20161123.t115346.658555.gif",
                "https://salt.tikicdn.com/cache/280x280/ts/product/8f/a7/27/c9f0ea2d4422f10af6233d18b00a3488.jpg",
                "https://salt.tikicdn.com/cache/280x280/ts/product/c1/d8/48/c0eae6581881e095b04db021554fcfa0.jpg",
                "https://salt.tikicdn.com/cache/280x280/ts/product/23/f0/51/9b632419ed8cf712f724457d62767d6c.jpg",
                "https://salt.tikicdn.com/cache/280x280/ts/product/1d/50/74/9cdf26c465be878ed44f9936212ff88f.jpg",
                "https://salt.tikicdn.com/cache/280x280/ts/product/80/14/8b/61fb657f347d14d9d7bf6fe901001a8e.jpg",
                "https://salt.tikicdn.com/cache/280x280/ts/product/ba/a8/3a/ced939a3c5058cb30c8976b397bb8ff4.png",
                "https://salt.tikicdn.com/cache/280x280/ts/product/97/28/e0/4deb081fdc4720a6aab965b0881197c4.jpg",
                "https://salt.tikicdn.com/cache/280x280/ts/product/b8/75/31/c0bab77a80666cc81c633d3a942b0fa3.jpg",
                "https://salt.tikicdn.com/cache/280x280/ts/product/24/12/a1/80df57a1e4f3763e23a9a96fce6efdaa.jpg",
                "https://salt.tikicdn.com/cache/280x280/ts/product/b4/1c/ec/bdc503738066a4d9c5c5e600a4e3a3bd.jpg"
        };

        flashDealItems = new ArrayList<>(flashDealUrl.length);

        for (int i=0; i<flashDealUrl.length; ++i) {
            flashDealItems.add(new FlashDealItem(flashDealUrl[i]));
        }

        requestBanner();
        requestQuickLink();

    }

    void requestBanner() {
        Request request = new Request.Builder().url("https://api.tiki.vn/v2/home/banners/v2").build();
        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {

            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                bannerItems = gson.fromJson(response.body().string(), BannerItems.class);
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        renderBanner();
                    }
                });


            }
        });
    }

    static String ss = "{\"data\":[[{\"title\":\"Mã giảm giá\",\"content\":\"\",\"url\":\"https://tiki.vn/chuong-trinh/ma-giam-gia\",\"authentication\":false,\"web_url\":\"\",\"image_url\":\"https://salt.tikicdn.com/ts/upload/73/50/e1/83afc85db37c472de60ebef6eceb41a7.png\"},{\"title\":\"Deal 0đ\",\"content\":\"\",\"url\":\"https://tiki.vn/chuong-trinh/deal-0-dong-chao-ban-moi\",\"authentication\":false,\"web_url\":\"\",\"image_url\":\"https://salt.tikicdn.com/ts/upload/79/76/e8/f09488f10ea645f4ccbac28ae20e8f9e.png\"},{\"title\":\"Săn thưởng\",\"content\":\"\",\"url\":\"tikivn://rewards\",\"authentication\":false,\"web_url\":\"\",\"image_url\":\"https://salt.tikicdn.com/ts/upload/db/1e/2d/07dc4d7136b450a3d2e1e689582213b2.png\"},{\"title\":\"Hoàn tiền 15%\",\"content\":\"\",\"url\":\"https://tiki.vn/chuong-trinh/mo-the-tikicard\",\"authentication\":false,\"web_url\":\"\",\"image_url\":\"https://salt.tikicdn.com/ts/upload/52/50/73/0788d5207ec8b82e05859dfe953a4327.png\"},{\"title\":\"Giá sốc\",\"content\":\"\",\"url\":\"tikivn://hot-deal\",\"authentication\":false,\"web_url\":\"\",\"image_url\":\"https://salt.tikicdn.com/ts/upload/e7/32/e2/c6a50df6d04cf212dcbda300e3cb8654.png\"},{\"title\":\"Giải trí\",\"content\":\"\",\"url\":\"https://tiki.vn/ticketbox\",\"authentication\":false,\"web_url\":\"\",\"image_url\":\"https://salt.tikicdn.com/ts/upload/58/26/1b/b98f5fc231b4505700bf7da5481fedad.png\"},{\"title\":\"TikiLIVE\",\"content\":\"TikiLIVE\",\"url\":\"tikivn://live\",\"authentication\":false,\"web_url\":\"\",\"image_url\":\"https://salt.tikicdn.com/ts/upload/81/f2/80/c130002f1ffd5c1131812366d502e36a.png\"}],[{\"title\":\"Danh mục\",\"content\":\"\",\"url\":\"tikivn://categories\",\"authentication\":false,\"web_url\":\"\",\"image_url\":\"https://salt.tikicdn.com/ts/upload/ec/a9/8e/3040afd931ce300038790ce6c9ad4f76.png\"},{\"title\":\"FREESHIP\",\"content\":\"\",\"url\":\"https://tiki.vn/chuong-trinh/tikinow-uu-dai-tiet-kiem\",\"authentication\":false,\"web_url\":\"\",\"image_url\":\"https://salt.tikicdn.com/ts/upload/ce/ee/fe/a8a350727b38a1e20ce1610c5162fcb7.png\"},{\"title\":\"Mới & HOT\",\"content\":\"\",\"url\":\"https://tiki.vn/chuong-trinh/tiki-new-arrival-hang-moi-ve\",\"authentication\":false,\"web_url\":\"\",\"image_url\":\"https://salt.tikicdn.com/ts/upload/23/85/ba/0c14258c1c040cfda5bcc2da367c5d90.png\"},{\"title\":\"Bách hoá online\",\"content\":\"\",\"url\":\"https://tiki.vn/bach-hoa-online/c4384\",\"authentication\":false,\"web_url\":\"\",\"image_url\":\"https://salt.tikicdn.com/ts/upload/0b/68/92/c5366849dc64b513569947c111117d8f.png\"},{\"title\":\"Tươi sống\",\"content\":\"\",\"url\":\"tikivn://tikingon\",\"authentication\":false,\"web_url\":\"\",\"image_url\":\"https://salt.tikicdn.com/ts/upload/a0/0d/90/bab67b6da67117f40538fc54fb2dcb5e.png\"},{\"title\":\"Ưu đãi đối tác\",\"content\":\"\",\"url\":\"https://tiki.vn/chuong-trinh/uu-dai-doi-tac\",\"authentication\":false,\"web_url\":\"\",\"image_url\":\"https://salt.tikicdn.com/ts/upload/4a/b2/c5/b388ee0e511889c83fab1217608fe82f.png\"},{\"title\":\"Tiện ích\",\"content\":\"\",\"url\":\"https://tiki.vn/dich-vu-tien-ich\",\"authentication\":false,\"web_url\":\"\",\"image_url\":\"https://salt.tikicdn.com/ts/upload/f2/5f/22/dae57676693b7665b734e36c5fb69809.png\"}]]}";

    void requestQuickLink() {
        Request request = new Request.Builder().url("https://api.tiki.vn/shopping/v2/widgets/quick_link").build();
        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {

            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                quickLinkItems = gson.fromJson(response.body().string(), QuickLinkItems.class);
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        renderQuickLink();
                    }
                });
            }
        });
    }

    void renderBanner(){
        List<BannerItems.Item> data = bannerItems.data;
        final AdapterBanner adapterBanner = new AdapterBanner(this, data, new Adapter.OnAllViewLoaded() {
            @Override
            public void onAllViewLoaded() {
                //renderQuickLink();
                bannerProgressBar.setVisibility(View.GONE);
                viewPager.setVisibility(View.VISIBLE);
            }

            @Override
            public void onAllViewFailedToLoad() {
                //renderQuickLink();
                bannerParent.setVisibility(View.GONE);
                System.out.println("======= load banner all failed");
            }
        });
        viewPager.setAdapter(adapterBanner);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            viewPager.setNestedScrollingEnabled(false);
        }
        viewPager.setOverScrollMode(ViewPager2.OVER_SCROLL_NEVER);
        viewPager.setCurrentItem(adapterBanner.getMiddlePostion(), false);
        viewPager.registerOnPageChangeCallback(new ViewPager2.OnPageChangeCallback() {
            @Override
            public void onPageScrollStateChanged(int state) {
                super.onPageScrollStateChanged(state);
                System.out.println("======= page state changed " + state + " - position " + viewPager.getCurrentItem());
                if (state == ViewPager2.SCROLL_STATE_IDLE) {
                    if (viewPager.getCurrentItem() == adapterBanner.getItemCount() - 1) {
                        viewPager.setCurrentItem(adapterBanner.getMiddlePostion() - 1, false);
                        System.out.println("======= page loop end");
                    }
                    else if (viewPager.getCurrentItem() == 0) {
                        viewPager.setCurrentItem(adapterBanner.getMiddlePostion(), false);
                        System.out.println("======= page loop back");
                    }

                }
            }
        });
    }

    void renderQuickLink() {
        quickLinkParent.setVisibility(View.VISIBLE);
        quickLinkView.setHasFixedSize(true);
        LinearLayoutManager layoutManager = new LinearLayoutManager(this, RecyclerView.HORIZONTAL, false);
        quickLinkView.setLayoutManager(layoutManager);
        AdapterQuickLink adapter = new AdapterQuickLink(this, quickLinkItems, new Adapter.OnAllViewLoaded() {
            @Override
            public void onAllViewLoaded() {
                if (toast != null)
                    toast.cancel();
                toast = Toast.makeText(ScrollingActivity.this, "done", Toast.LENGTH_SHORT);
                toast.show();

                renderFlashDeal(flashDealItems);
                quickLinkProgressBar.setVisibility(View.GONE);
                quickLinkView.setVisibility(View.VISIBLE);
            }

            @Override
            public void onAllViewFailedToLoad() {
                renderFlashDeal(flashDealItems);
                quickLinkParent.setVisibility(View.GONE);
                System.out.println("======= load quick link all failed");
            }
        });
        quickLinkView.setAdapter(adapter);
        quickLinkView.setNestedScrollingEnabled(false);
    }

    void renderFlashDeal(ArrayList<FlashDealItem> data) {
        flashDealParent.setVisibility(View.VISIBLE);
        flashDealView.setHasFixedSize(true);
        LinearLayoutManager layoutManager2 = new LinearLayoutManager(this, RecyclerView.HORIZONTAL, false);
        flashDealView.setLayoutManager(layoutManager2);
        AdapterFlashDeal adapter2 = new AdapterFlashDeal(this, data, new Adapter.OnAllViewLoaded() {
            @Override
            public void onAllViewLoaded() {
                if (toast != null)
                    toast.cancel();
                toast = Toast.makeText(ScrollingActivity.this, "done 2", Toast.LENGTH_SHORT);
                toast.show();

                flashDealProgressBar.setVisibility(View.GONE);
                flashDealView.setVisibility(View.VISIBLE);
            }

            @Override
            public void onAllViewFailedToLoad() {
                flashDealParent.setVisibility(View.GONE);
                System.out.println("======= load flash deal all failed");

            }
        });
        flashDealView.setAdapter(adapter2);
        flashDealView.setNestedScrollingEnabled(false);
    }


    @Override
    protected void onDestroy() {
        super.onDestroy();
        Glide.get(ScrollingActivity.this).clearMemory();
        new Thread(new Runnable() {
            @Override
            public void run() {
                Glide.get(ScrollingActivity.this).clearDiskCache();

            }
        }).start();

    }

    private void transparentStatusBar() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            getWindow().addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
            getWindow().clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
            getWindow().addFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_NAVIGATION);
            getWindow().setStatusBarColor(Color.TRANSPARENT);
        } else {
            getWindow().addFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_scrolling, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}
