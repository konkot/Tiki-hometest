package com.tt.hometest;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.DrawFilter;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.util.AttributeSet;
import android.view.View;
import android.widget.ImageView;

import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;

public class RoundedCornersView extends androidx.appcompat.widget.AppCompatImageView {


    private Bitmap bitmap;
    private Paint paint;
    private Rect bound = new Rect();
    private RectF boundF = new RectF();

    public RoundedCornersView(Context context) {
        super(context);
    }

    public RoundedCornersView(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    public RoundedCornersView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        if (getDrawable() == null)
            return;
        if (paint == null) {
            paint = new Paint();
            paint.setAntiAlias(true);
        }
        if (bitmap == null) {
            bitmap = ((BitmapDrawable) getDrawable()).getBitmap();
            if (bitmap == null)
                return;
            //bitmap = getRoundedCornerBitmap(bitmap);
        }


        //super.onDraw(canvas);
        //canvas.drawBitmap(bitmap, 0, 0, paint);

        canvas.getClipBounds(bound);
        boundF.set(bound);
        canvas.drawARGB(0, 0, 0, 0);
        paint.setColor(0xff424242);
        canvas.drawRoundRect(boundF, 20, 20, paint);
        paint.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.SRC_IN));
        canvas.drawBitmap(bitmap, null, bound, paint);
        System.out.println("======= draw ");

    }

    public static Bitmap getRoundedCornerBitmap(Bitmap bitmap) {
        Bitmap output = Bitmap.createBitmap(bitmap.getWidth(),
                bitmap.getHeight(), Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(output);

        final int color = 0xff424242;
        final Paint paint = new Paint();
        final Rect rect = new Rect(0, 0, bitmap.getWidth(), bitmap.getHeight());
        final RectF rectF = new RectF(rect);
        final float roundPx = 24;

        paint.setAntiAlias(true);
        canvas.drawARGB(0, 0, 0, 0);
        paint.setColor(color);
        canvas.drawRoundRect(rectF, roundPx, roundPx, paint);

        paint.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.SRC_IN));
        canvas.drawBitmap(bitmap, rect, rect, paint);

        return output;


    }
}
