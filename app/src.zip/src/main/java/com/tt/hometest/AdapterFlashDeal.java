package com.tt.hometest;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class AdapterFlashDeal extends Adapter<AdapterFlashDeal.ViewHolder> {

    ArrayList<FlashDealItem> data;

    public AdapterFlashDeal(Context context, ArrayList<FlashDealItem> data,  OnAllViewLoaded onLoadedCallback) {
        super(context, onLoadedCallback);
        this.data = data;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = inflater.inflate(R.layout.item_flash_deal, parent, false);
        ViewHolder holder = new ViewHolder(v);
        return holder;
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        loadImage(holder, holder.imageView, data.get(position).imageURL);
    }

    @Override
    public int getItemCount() {
        return data.size();
    }

    public static class ViewHolder extends Adapter.ViewHolder {
        public ImageView imageView;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            imageView = itemView.findViewById(R.id.imageView);
        }
    }
}
