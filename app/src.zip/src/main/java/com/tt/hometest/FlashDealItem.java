package com.tt.hometest;

public class FlashDealItem {

    public String imageURL;

    public FlashDealItem(String url) {
        imageURL = url;
    }
}
