package com.tt.hometest;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.media.Image;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageSwitcher;
import android.widget.ImageView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.RequestBuilder;
import com.bumptech.glide.load.DataSource;
import com.bumptech.glide.load.engine.GlideException;
import com.bumptech.glide.request.RequestListener;
import com.bumptech.glide.request.target.CustomTarget;
import com.bumptech.glide.request.target.Target;
import com.bumptech.glide.request.transition.Transition;

import java.util.ArrayList;
import java.util.List;

public abstract class Adapter<VH extends Adapter.ViewHolder> extends RecyclerView.Adapter<VH> {

    Context context;
    LayoutInflater inflater;

    public interface OnAllViewLoaded {
        void onAllViewLoaded();
        void onAllViewFailedToLoad();
    }

    OnAllViewLoaded onLoadedCallback;
    /*protected int loadingItem, loadedItem, failedItem;
    protected boolean firstLoad = true;*/
    private ArrayList<ViewHolder> processingViews = new ArrayList<>();

    public Adapter(Context context, OnAllViewLoaded onLoadedCallback) {
        this.context = context;
        inflater = LayoutInflater.from(context);
        this.onLoadedCallback = onLoadedCallback;

        Drawable d = ContextCompat.getDrawable(context, R.drawable.baseline_search_black_24);
        System.out.println("======= drawable " + (d instanceof BitmapDrawable));
        BitmapDrawable d2 = (BitmapDrawable) d;
        d2.getBitmap();
        Drawable d3 = new BitmapDrawable(context.getResources(), d2.getBitmap());
    }

    protected void checkLoaded() {
        int loadOKCount = 0, loadFailedCount = 0;
        System.out.println("======= check " + processingViews.size());
        for (int i=0; i<processingViews.size(); ++i) {
            ViewHolder holder = processingViews.get(i);
            if (holder.loadState == ViewHolder.STATE_LOAD_OK)
                loadOKCount++;
            else if (holder.loadState == ViewHolder.STATE_LOAD_FAILED)
                loadFailedCount++;
            System.out.println("======= check element " + i + " "  + holder.loadState);
        }
        if (loadFailedCount == processingViews.size()) {
            System.out.println("======= check loaded 1 " + loadOKCount + " " + loadFailedCount + " " + processingViews.size());
            processingViews = null;
            onLoadedCallback.onAllViewFailedToLoad();
        } else if (loadFailedCount + loadOKCount == processingViews.size()) {
            System.out.println("======= check loaded 2 " + loadOKCount + " " + loadFailedCount + " " + processingViews.size());
            processingViews = null;
            onLoadedCallback.onAllViewLoaded();
        }

    }

    protected void loadImage(final VH holder, ImageView view, String url) {
        if (url == null) {
            Glide.with(context).clear(view);
            return;
        }
        if (processingViews != null) {
            processingViews.add(holder);
            Glide.with(context).load(url).listener(new RequestListener<Drawable>() {
                @Override
                public boolean onLoadFailed(@Nullable GlideException e, Object model, Target<Drawable> target, boolean isFirstResource) {
                    holder.loadState = ViewHolder.STATE_LOAD_FAILED;
                    System.out.println("========= load failed " + Adapter.this.getClass().getSimpleName());
                    checkLoaded();
                    return false;
                }

                @Override
                public boolean onResourceReady(Drawable resource, Object model, Target<Drawable> target, DataSource dataSource, boolean isFirstResource) {
                    holder.loadState = ViewHolder.STATE_LOAD_OK;
                    System.out.println("========= load ok " + Adapter.this.getClass().getSimpleName() + " " + (processingViews == null ? "null" : processingViews.size()));
                    checkLoaded();
                    return false;
                }
            }).into(view);
        } else
            Glide.with(context).load(url).into(view);
    }

    protected void loadImageAsBitmap(final ViewHolder holder, final ImageView view, String url, final boolean roundCorners) {
        if (url == null) {
            Glide.with(context).clear(view);
            return;
        }
        if (processingViews != null) {
            Glide.with(context).asBitmap().load(url).listener(new RequestListener<Bitmap>() {
                @Override
                public boolean onLoadFailed(@Nullable GlideException e, Object model, Target<Bitmap> target, boolean isFirstResource) {
                    holder.loadState = ViewHolder.STATE_LOAD_FAILED;
                    System.out.println("========= load failed " + Adapter.this.getClass().getSimpleName());
                    checkLoaded();
                    return false;
                }

                @Override
                public boolean onResourceReady(Bitmap resource, Object model, Target<Bitmap> target, DataSource dataSource, boolean isFirstResource) {
                    holder.loadState = ViewHolder.STATE_LOAD_OK;
                    System.out.println("========= load ok " + Adapter.this.getClass().getSimpleName());
                    checkLoaded();
                    return false;
                }
            }).into(new CustomTarget<Bitmap>() {
                @Override
                public void onResourceReady(@NonNull Bitmap resource, @Nullable Transition<? super Bitmap> transition) {
                    view.setImageBitmap(roundCorners ? getRoundedCornerBitmap(resource) : resource);
                }

                @Override
                public void onLoadCleared(@Nullable Drawable placeholder) {

                }
            });
        } else
            Glide.with(context).asBitmap().load(url).into(new CustomTarget<Bitmap>() {
                @Override
                public void onResourceReady(@NonNull Bitmap resource, @Nullable Transition<? super Bitmap> transition) {
                    view.setImageBitmap(getRoundedCornerBitmap(resource));
                }

                @Override
                public void onLoadCleared(@Nullable Drawable placeholder) {

                }
            });
    }

    private Drawable mask; Paint paint; Rect bound = new Rect();

    public Bitmap getRoundedCornerBitmap(Bitmap bitmap) {
        if (mask == null)
            mask = ContextCompat.getDrawable(context, R.drawable.rounded_bar_2);
        if (paint == null) {
            paint = new Paint(Paint.ANTI_ALIAS_FLAG);
                paint.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.SRC_IN));
        }
        Bitmap output = Bitmap.createBitmap(bitmap.getWidth(), bitmap.getHeight(), Bitmap.Config.ARGB_8888);
        Canvas tempCanvas = new Canvas(output);
        tempCanvas.getClipBounds(bound);
        mask.setBounds(bound);
        mask.draw(tempCanvas);
        tempCanvas.drawBitmap(bitmap, 0, 0, paint);
        return output;

    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        static int STATE_UNPROCESSED = 0;
        static int STATE_LOAD_FAILED = 1;
        static int STATE_LOAD_OK = 2;

        int loadState = STATE_UNPROCESSED;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
        }
    }

}
