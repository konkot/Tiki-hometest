package com.tt.hometest;

import android.content.Context;
import android.content.Intent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewpager.widget.PagerAdapter;

import com.tt.hometest.model.banner.BannerItems;

import java.util.ArrayList;
import java.util.List;

public class AdapterBanner extends Adapter<AdapterBanner.ViewHolder> {

    List<BannerItems.Item> data;

    public AdapterBanner(Context context, List<BannerItems.Item> data, OnAllViewLoaded onLoadedCallback) {
        super(context, onLoadedCallback);
        this.data = data;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = inflater.inflate(R.layout.item_banner, parent, false);
        ViewHolder holder = new ViewHolder(v);
        System.out.println("======= banner create page");
        return holder;
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        position = position % data.size();
        loadImageAsBitmap(holder, holder.imageView, data.get(position).getMobileUrl(), true);
        System.out.println("======= banner bind page");
    }

    @Override
    public int getItemCount() {
        if (data.size() == 1)
            return 1;
        //return Integer.MAX_VALUE - Integer.MAX_VALUE % getRealItemCount();
        return getRealItemCount()*4;
    }

    public int getRealItemCount() {
        return data.size();
    }

    public int getMiddlePostion(){
        //int m = getItemCount()/2;
        //return m - m % getRealItemCount();
        return getItemCount()/2;
    }

    public static class ViewHolder extends Adapter.ViewHolder {
        public ImageView imageView;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            imageView = itemView.findViewById(R.id.imageView);
        }
    }
}
